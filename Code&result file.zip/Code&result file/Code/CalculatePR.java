package pagerank.cal;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import Jama.Matrix;
import rhq.pr.data.Weight;

public class CalculatePR {

    /**
     * @param args
     * @throws IOException 
     */
    public static void main(String[] args) throws IOException {
    	    double d =0.15;
    		GetMa m = new GetMa();//获取文件处理对象
    		ArrayList<String> sd = m.getMetadata("newvenue.txt");//获取链表形式的原数据 
    		ArrayList<String> fCommunity = m.getMetadata("final.txt");//获取FINAL COMMUNITY.txt中的数据 
    		ArrayList<Weight> wd = m.getWeight("08-12 weight f3 indegree.txt");//获取权重数据
    		double[][] wArray = m.getWeightM(sd.size(),sd,wd);//获取与原数据匹配的权重矩阵 二维数组形式
    		int n = sd.size();//原数据的个数为3293 or 640
            
            
            double  threshold = 0.000000000000001d;//threshold value  最后作比较时使用
            
            Matrix oc =  getOC(wArray);//获取每行不为零个数的倒数组成的1*n的矩阵 
            Matrix w= new Matrix(wArray);            
            Matrix p = getP(wArray,oc);//把原来的weight matrix权重矩阵中不为0的项，变为这一行不为零项个数的倒数        
            p=p.transpose();//获得p的转置矩阵          
            Matrix ee = new Matrix(n,n,1d/7205);//默认每个venue初始的重要性一样 目前n=3293 n*n的方阵      
            Matrix x = new Matrix(n,1,1d);
            
            Matrix a = w.times(p).times(d).plus(ee.times(1-d));
            //Matrix  a =b.times(w);
            Matrix  r = a.times(x);
      
           int iter =1;
           while(true){
                        if(compareAbs( threshold,x.minus(r))){//满足threshold value条件即跳出循环
                                break;
                        }else{//继续迭代
                                x = r;
                                r =  a.times(x);
                                iter ++;
                        }
            }
           
            System.out.println("迭代次数："+iter);
            
            //提取出FINAL COMMUNITY.txt中对应的r值,不存在的项，fr值都默认为0
            Matrix  fr= getfCommunityRank(r,sd,fCommunity);
            
          //排序并输出FINAL COMMUNITY.txt中出现的结果
           rankSort(fr, fCommunity,iter);
         //排序并输出全部的结果
           //rankSort(r, sd,iter);
    }          


    /**
     * 提取出FINAL COMMUNITY.txt文件中对应的r值,为后面输出FINAL COMMUNITY.txt的结果使用
     * @param r
     * @param sd
     * @param fCommunity
     * @return
     */
    private static Matrix getfCommunityRank(Matrix r, ArrayList<String> sd, ArrayList<String> fCommunity) {
		double[][] fr = new double[fCommunity.size()][1];
		String temp;
		for(int i=0;i<fCommunity.size();i++){
			for(int j=0;j<sd.size();j++){
				temp = sd.get(j);
				temp = temp.substring(0, temp.length()-2);
				if(temp.equals(fCommunity.get(i))){
					fr[i][0]=r.get(j, 0);
				}
			}
		}
		//System.out.println("----匹配的个数----:"+count+","+fCommunity.size());
		return new Matrix(fr);
	}



	/**
     * 把原来的weight matrix权重矩阵中不为0的项，变为这一行不为零项个数的倒数
     * @param wArray
     * @return
     */
	private static Matrix getP(double[][] wArray,Matrix oc) {
		for(int i=0; i<wArray.length; i++){
			for(int j=0; j<wArray.length; j++){
				if(wArray[i][j]!=0)wArray[i][j]=oc.get(0, i);
			}
		}
		return new Matrix(wArray);
	}

	/**
	 * 获取wm矩阵中每行不为零数据的个数，生成一个1*n的矩阵  为了乘以Wij的每一行
	 * @param wm
	 * @return
	 */
	public static Matrix getOC(double[][] wm) {
		 	double[][] oc = new double[1][wm.length];
		 	double count = 0;
			for(int i=0;i<wm.length;i++){
				for(int j=0;j<wm.length;j++){
					if(wm[i][j]!=0.0d){
						count+=1.0d;
					}
				}
				if(count!=0.0d){
					oc[0][i]=1/count;
				}else {//如果此行所有数都为零则count以矩阵长度计算
					oc[0][i]=1/wm.length;
				}
				count=0;
			}
		 
			return new Matrix(oc);
		}
	
      
    /**
     * 比较CR[i-1]-CR[i]的值，如果小于threshold value ( |threshold| > |b(ij)| ) 则认为数值收敛，返回true，否则返回false
     * @param a
     * @param b
     * @return
     */
    public static boolean compareAbs(double threshold,Matrix b){
            boolean flag = true;
            for(int i=0;i<b.getRowDimension();i++){
                    for(int j=0;j<b.getColumnDimension();j++){
                            if(Math.abs(threshold)<=Math.abs(b.get(i, j))){//取绝对值比较
                                    flag = false;break;
                            }
                    }
            }
            return flag;
    }
    
    /**
     * 对pagerank进行排序输出,并保存在文件中  其中pagerank为1*n的矩阵
     * @throws IOException 
     */
    public static void rankSort(Matrix pagerank,ArrayList<String> s,int iter) throws IOException{
    	HashMap<String,Double> rMap = new HashMap<String,Double>(); 
    	
    	for(int i =0;i<s.size();i++){
    		rMap.put(s.get(i), pagerank.get(i, 0));//如果pagerank为1*n的矩阵则pagerank.get(i, 0)改为pagerank.get(0,i)
    	}
    	
    	List<Map.Entry<String, Double>> infoIds = new ArrayList<Map.Entry<String, Double>>(  
    	        rMap.entrySet()); 
    	
    	// 排序  
    	Collections.sort(infoIds, new Comparator<Map.Entry<String, Double>>() {  
    	    public int compare(Map.Entry<String, Double> o1,  
    	            Map.Entry<String, Double> o2) {  
    	    	 return (o1.getValue() < o2.getValue()) ? 1 : o1.getValue()  == o2.getValue() ? 0 : -1;  
    	    }  
    	}); 
    	
    	System.out.println("--------------排序后--------------");  

    	
    	File file = new File("result-PR.txt");
		if(!file.exists()){
			//System.out.println("result-PR.txt:文件不存在，创建此文件");
			file.createNewFile();
		}		
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file)));
		pw.println("迭代次数"+":  "+iter);//保存迭代次数
		for (int i = 0; i < infoIds.size(); i++) {  
    	    Entry<String,Double> ent=infoIds.get(i);  
    	    System.out.println(ent.getKey()+":  "+ent.getValue());  
    	    pw.println(ent.getKey()+":  "+ent.getValue());
    	      
    	} 
		pw.close();
    	
    }


}
