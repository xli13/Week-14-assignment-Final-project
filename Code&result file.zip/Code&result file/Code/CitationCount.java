package entity;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;


public class CitationCount {

    String filename = new String("08-12 entities.txt");
    TreeMap<String, HashSet<String> > conferenceToArticleId = new TreeMap<String, HashSet<String>>();//venue to articles
    TreeMap<String, String> articleToId = new TreeMap<String, String>();//文章与id的映射关系
    TreeMap<String, String> idToArticle = new TreeMap<String, String>();//id与文章的映射关系
    TreeMap<String, String> articleIdToConf = new TreeMap<String, String>();


    TreeMap<String, Integer> matrix = new TreeMap<String, Integer>();//要计算的结果 string 为两个会议名相连
    TreeMap<String, Integer> conReferencedNum = new TreeMap<String, Integer>();//每一个会议被一共引用了多少次


    /*计算映射关系
     * articleToId就是  文章的名字对应的文章id
     * idToArticle就是  文章的id对应的文章的名字
     * articleIdToConf就是  文章的id对应的会议 文章属于哪一个会议
     */
    void getVenueandArticleInfo(){
        try {
            Scanner scanner = new Scanner(new FileInputStream(filename));

            String conference = null;
            String article = null;
            String artcileId = null;
            int year = 0;

            while (scanner.hasNextLine()){
                String line = scanner.nextLine();
                if (line.startsWith("#c")){
                    conference = line;
                } else if (line.startsWith("#*")){
                    article = line;
                } else if (line.startsWith("#index")){
                    artcileId = line.substring(6);

                    if (year >= 2008 && year <= 2012) {
                        
                        articleToId.put(article, artcileId);
                        idToArticle.put(artcileId, article);

                        articleIdToConf.put(artcileId, conference);
                    }
                } else if (line.startsWith("#t")){

                    year = Integer.parseInt(line.substring(2,6));
                }
            }
            scanner.close();

        }catch (IOException e){
            e.printStackTrace();
            return;
        }
    }
    void calculateMatrix(){
        try {
            Scanner scanner = new Scanner(new FileInputStream(filename));

            String conference = null;
            String article = null;
            String artcileId = null;
            TreeSet<String> refConferenceSet = new TreeSet<String>();
            int year = 0;

            while (scanner.hasNextLine()){
                String line = scanner.nextLine();
                if (line.startsWith("#c")){
                    conference = line;
                } else if (line.startsWith("#*")){
                    article = line;
                } else if (line.startsWith("#index")){
                    artcileId = line.substring(6);

                } else if (line.startsWith("#t")){
                    year = Integer.parseInt(line.substring(2,6));
                } else if (line.startsWith("#%")){

                    //这一行为这一篇文章引用了的文章的id
                    //获取引用的这篇文章的会议名称是什么  加入该文章引用的会议的集合
                    String tmp = articleIdToConf.get(line.substring(2));
                    if (tmp != null)
                        tmp = tmp.trim();

                    if (tmp != null && tmp.length() != 0)
                        refConferenceSet.add(tmp);

                } else if (line.startsWith("#!")){

                    //读取到这个说明一篇文章的信息读取完毕
                    //只计算08--12年的

                    if (year >= 2008 && year <= 2012){
                        Iterator<String> it = refConferenceSet.iterator();

                        //遍历这篇文章引用的会议的集合
                        while (it.hasNext()) {
                            String conf2 = it.next();

                            //把两个会议的名称相连 代表矩阵的ij 将一个二维矩阵映射为一维矩阵
                            String concon= conference + "     &&&\t" + conf2;//两个会议

                            Integer num;

                            //计算conference引用了conf2多少次
                            if ((num = matrix.get(concon)) != null){
                                matrix.put(concon, num+1);
                            }else {
                                matrix.put(concon, 1);
                            }

                            //计算conf2一共被引用了多少次
                            if ((num = conReferencedNum.get(conf2)) != null){
                                conReferencedNum.put(conf2, num+1);
                            }else {
                                conReferencedNum.put(conf2, 1);
                            }
                        }
                    }

                    refConferenceSet = new TreeSet<String>();
                }
            }
            scanner.close();

        }catch (IOException e){
            e.printStackTrace();
            return;
        }

    }


    void printMatrix(){
        try {
            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(("Citation.txt")));

            Iterator iter = matrix.entrySet().iterator();
            while (iter.hasNext()) {
                Map.Entry entry = (Map.Entry) iter.next();
                String key = (String)(entry.getKey());
                double val = (Integer)(entry.getValue());
                String conference = key.substring(key.indexOf('\t') + 1);
                if (conference == null){
                    System.out.println(key);
                }

                //获取conference一共被引用了多少次
                String []conferences = key.split("     &&&\t");
                //String conference=conferences[0];
                double totalNum = conReferencedNum.get(conferences[1]);

                bufferedWriter.write(key + ":\t" + val);//输出并计算结果
                bufferedWriter.write(key+":\t"   +totalNum);
                bufferedWriter.newLine();
            }
            bufferedWriter.close();

        }catch (Exception e){
            e.printStackTrace();
        }

    }




    public static void main(String[] argv){
        PaperCount paperCount = new PaperCount();

        paperCount.getVenueandArticleInfo();
        paperCount.calculateMatrix();
        paperCount.printMatrix();

    }
}
