package Experiment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import Jama.Matrix;
import implemention.Weight;

public class GetMatrix {
	
	/**
	 * Get original data.
	 * @param path 
	 * @return
	 * @throws IOException
	 */
	public ArrayList<String> getMetadata(String path) throws IOException{
		ArrayList<String> metadata = new ArrayList<String> ();//元数据大小
		File metadataFile = new File(path);
		if(metadataFile.isFile() && metadataFile.exists()){ //判断文件是否存在
			 InputStreamReader read = new InputStreamReader(
	                    new FileInputStream(metadataFile));
	                    BufferedReader bufferedReader = new BufferedReader(read);
	                    String lineTxt = null;
	                    while((lineTxt = bufferedReader.readLine()) != null){//按行读取内容	          
	                    	metadata.add(lineTxt.trim());//去掉字符串的前后空格
	                    }
	                    read.close();
	        }else{
	            System.out.println("No File!"+path);
	        }
		
 		return metadata;
	}
	
	
	
	public ArrayList<Weight> getWeight(String path) throws IOException{
		ArrayList<Weight> weightdata = new ArrayList<Weight> ();//元数据大小
		File file = new File(path);
		
		if(file.isFile() && file.exists()){ //判断文件是否存在
			 InputStreamReader read = new InputStreamReader(
	                    new FileInputStream(file));
	                    BufferedReader bufferedReader = new BufferedReader(read);
	                    String lineTxt = null;
	                    while((lineTxt = bufferedReader.readLine()) != null){            	
	                        //System.out.println("00000000000:"+lineTxt);
	                        String[] st = lineTxt.split("&&&|:");//对文件以“&&&”和“：”进行分割
	                        if(st.length!=3){//对特殊格式进行重新分割，如其数据本身含有“：”的
	                        	//System.out.println("**************************err:"+lineTxt);//输出错误数据
	                        	String[] st_1 = lineTxt.split("&&&");//先以“&&&”把数据分割成两部分，第一部分肯定是要获得的数据
	                        	st[0]=st_1[0];//将第一部分数据重新赋给st[0]
	                        	String[] st_2 = st_1[1].split(":");//将st_1后半部分的数据以“：”把数据分割，其中分割后的最后数据肯定是权重值
	                        	st[2]=st_2[st_2.length-1];//把权重值赋值给st[2]
	                        	st[1]="";
	                        	for(int i=0;i<st_2.length-1;i++){//获得第二部分的数据
	                        		st[1] = st[1]+st_2[i];
	                        	}             
	                        }
	                       Weight temp = new Weight();
	                        temp.d1 = st[0].trim();
	                        temp.d2 = st[1].trim();
	                        String w = st[2].trim();                        
	                        temp.weight =  Double.parseDouble(w.substring(0, w.length()-1));
	                        weightdata.add(temp);
	                    }
	                    read.close();
	        }else{
	            System.out.println("NO File!"+path);
	        }
		
 		return weightdata;	
	}
	
	/**
	 * 首先遍历权重数据将第一部分d1与原数据（即890个数据）进行比较看是否在其中：
	 * 1、如果不存在，则继续遍历权重数据
	 * 2、如果d1在890个数据中存在，且在j的位置，则继续匹配数据d2，如果d2也在890个数据中，且在k位置，则找到一个有效的权重值，即wm[j][k]中的值
	 * 	  如果d1存在890个数据中，d2不存在其中，则此权重数据也无效，继续遍历权重数据
	 * 
	 * 
	 * @param n 数据的长度，这里面是md的大小即890
	 * @param md 元数据的链表
	 * @param wd  权重数据的链表
	 * @return
	 */
	public double[][] getWeightM(int n,ArrayList<String> md,ArrayList<Weight> wd){//获取权重矩阵
		int count =0;
		double[][] wm = new double[n][n];
		for(int i=0;i<wd.size();i++){//遍历权重数据
			for(int j=0;j<md.size();j++){//遍历原数据，匹配d1
				if(wd.get(i).d1.equals(md.get(j))){//判断d1是否匹配成功
					for(int k=0;k<md.size();k++){//遍历原数据，匹配d2
						if(wd.get(i).d2.equals(md.get(k))){//判断d2是否匹配成功
							wm[j][k]=wd.get(i).weight;
							count++;
						}
					}
				}
			}
		}	

		return wm;
	}
	
	/**
	 * 将矩阵保存在文件中
	 * @param m
	 * @param path
	 * @throws IOException
	 */
	public void saveMatrix2File(Matrix m , String path) throws IOException{
		File file = new File(path);
		if(!file.exists()){
			System.out.println("No File!");
			file.createNewFile();
		}		
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file)));
		m.print(pw, 2, 10);
	}
	
	
	/**
	 * 筛选weight中不重复的数据，即获得890.txt的函数
	 * @param w
	 * @return
	 * @throws IOException
	 */
	public ArrayList<String> getnewWeightList(ArrayList<Weight> w) throws IOException{//筛选weight中不重复的数据
		ArrayList<String> wl = new ArrayList<String>();
		wl.add(w.get(0).d1);
		for(Weight t : w){
			if(!t.d1.equals(wl.get(wl.size()-1))){
				//System.out.println(t.d1);
				wl.add(t.d1);
			}
		}
		boolean flag=true;
		for(Weight t : w){
			for(int i=0;i<wl.size();i++){
				if(t.d2.equals(wl.get(i))){
					flag=false;
				}			
			}
			if(flag){
				//System.out.println(t.d2);
				wl.add(t.d2);
			}else
			flag = true;
		}
		
		File file = new File("Exist Community.txt");
		if(!file.exists()){
			System.out.println("No File!");
			file.createNewFile();
		}		
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(String temp : wl){
			pw.println(temp);
		}
		pw.close();
		System.out.println(wl.size());
		
		return null;
	}
	
	
	public static void main(String[] args) throws IOException{
		GetMatrix m = new GetMatrix();
		ArrayList<String> md = m.getMetadata("Exist Community.txt");//获取链表形式的原数据     
		ArrayList<Weight> wd = m.getWeight("2012-weight.txt");//获取权重数据
		//m.getnewWeightList(wd); //筛选weight中不重复的数据，即获得890.txt的函数
		double[][] wm = m.getWeightM(md.size(),md,wd);//获取与原数据匹配的权重矩阵 二维数组形式
		Matrix w = new Matrix(wm);//最终的权重矩阵
		m.saveMatrix2File(w, "weight_matrix.txt");//把权重矩阵保存到文件中
	}

}