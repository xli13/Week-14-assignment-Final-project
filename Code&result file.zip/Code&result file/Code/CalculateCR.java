package pagerank.cal;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import Jama.Matrix;
import rhq.pr.data.Weight;

public class CalculateCR {

        /**
         * @param args
         * @throws IOException 
         */
        public static void main(String[] args) throws IOException {
        	    double d =0.85;
        		GetMa m = new GetMa();//获取文件处理对象
        		ArrayList<String> sd = m.getMetadata("newvenue.txt");//获取链表形式的原数据     
        		ArrayList<String> fCommunity = m.getMetadata("final.txt");//获取FINAL COMMUNITY.txt中的数据 
        		ArrayList<Weight> wd = m.getWeight("08-12 weight f2 indegree.txt");//获取权重数据
        		double[][] wArray = m.getWeightM(sd.size(),sd,wd);//获取与原数据匹配的权重矩阵 二维数组形式
        		int n = sd.size();//原数据的个数这里面为3293
                
                Matrix cR = new Matrix(1,n,1d/n);//默认每个venue初始的重要性一样 目前n=890  1*n的矩阵      
                double  threshold = 0.000000000000001d;//threshold value  最后作比较时使用
                Matrix w= new Matrix(wArray);//根据double[][] wArray生成权重矩阵 n*n的矩阵 
                //Matrix v=new Matrix(1,n,1-d);             
                Matrix oc =  getOC(wArray);//获取每行不为零的个数Oc,1/Oc组成的1*n的矩阵 
                Matrix oc_new =  getOC_New(wArray,oc);//获取新定义的oc即其不为零行的相关联行的不为零个数的和
                Matrix pageRankPre = cR;//保存前一轮 cR的值，即CR[i-1]
              
                /**
                 * 保存 d* [1/Oc * Wij]的值供后面迭代时使用,1*n.n*n  
                 * 即Wij的每一行乘以oc的值，
                 * 如果改为乘以每一列，就要变为n*n.n*1 即把oc的矩阵变为n*1的矩阵 然后式子变为 ：
                 * w.times(oc).times(d)
                 * 这时候相应的g也就变为了n*1的矩阵 ，cR和pageRankPre也都要变为n*1的矩阵
                 */ 
                
                Matrix g = oc_new.times(w).times(d); //保存 d* [1/Oc * Wij]的值供后面迭代时使用
                
               //开始迭代计算适合的CR值。  
                cR =  pageRankPre.times(1-d).plus(g);//CR[i]=（1-d）*CR[i-1]+g
                int iter =1;
               while(true){
                            if(compareAbs( threshold,pageRankPre.minus(cR))){//满足threshold value条件即跳出循环
                                    break;
                            }else{//继续迭代
                                    pageRankPre = cR;
                                    cR =  pageRankPre.times(1-d).plus(g);
                                    iter ++;
                            }
                }

                System.out.println("迭代次数："+iter);            
                //转置让其变为n*1的矩阵
                cR = cR.transpose();                
              //提取出FINAL COMMUNITY.txt中对应的r值,不存在的项，fr值都默认为0
                Matrix  fr= getfCommunityRank(cR,sd,fCommunity);
              //排序并输出FINAL COMMUNITY.txt中出现的结果
                rankSort(fr, fCommunity,iter);
              //排序并输出全部的结果
               //rankSort(cR, sd,iter);//进行排序并输出到文件中,同时也将迭代次数保存到文件中
        }          

        
        /**
         * 提取出FINAL COMMUNITY.txt文件中对应的r值，为后面输出FINAL COMMUNITY.txt的结果使用
         * @param r
         * @param sd
         * @param fCommunity
         * @return
         */
        private static Matrix getfCommunityRank(Matrix r, ArrayList<String> sd, ArrayList<String> fCommunity) {
    		double[][] fr = new double[fCommunity.size()][1];
    		String temp;
    		for(int i=0;i<fCommunity.size();i++){
    			for(int j=0;j<sd.size();j++){
    				temp = sd.get(j);
    				temp = temp.substring(0, temp.length()-2);//sd中数据后面的双斜杠
    				if(temp.equals(fCommunity.get(i))){
    					fr[i][0]=r.get(j, 0);
    				}
    			}
    		}
    		return new Matrix(fr);
    	}


		/**
    	 * 获取wm矩阵中每行不为零数据的个数，生成一个1*n的矩阵  为了乘以Wij的每一行
    	 * @param wm
    	 * @return
    	 */
    	public static Matrix getOC(double[][] wm) {
    		 	double[][] oc = new double[1][wm.length];
    		 	double count = 0;
    			for(int i=0;i<wm.length;i++){
    				for(int j=0;j<wm.length;j++){
    					if(wm[i][j]!=0.0d){
    						count+=1.0d;
    					}
    				}
    				if(count!=0.0d){
    					oc[0][i]=1/count;
    				}else {//如果此行所有数都为零则count以矩阵长度计算
    					oc[0][i]=1/wm.length;
    					//oc_new[0][i]=0;
    				}
    				count=0;
    			}
    		 
    			return new Matrix(oc);
    		}
    	
    	/**
    	 * //获取新定义的oc即其不为零行的相关联行的不为零个数的和
    	 * @param wArray
    	 * @param oc 1*n的矩阵
    	 * @return
    	 */
  
    	private static Matrix getOC_New(double[][] wm, Matrix oc) {
    		double[][] oc_new = new double[1][wm.length];
		 	double count = 0;
			for(int i=0;i<wm.length;i++){
				for(int j=0;j<wm.length;j++){
					if(wm[i][j]!=0.0d){
						count+=oc.get(0, j);//不为零项的 不为零个数的倒数之和
					}
				}
				if(count!=0.0d){
					oc_new[0][i]=count;
				}else {//如果此行所有数都为零则count以矩阵长度计算
					oc_new[0][i]=1/wm.length;
				}
				count=0;
			}
		 
			return new Matrix(oc_new);
		}
		
          
        /**
         * 比较CR[i-1]-CR[i]的值，如果小于threshold value ( |threshold| > |b(ij)| ) 则认为数值收敛，返回true，否则返回false
         * @param a
         * @param b
         * @return
         */
        public static boolean compareAbs(double threshold,Matrix b){
                boolean flag = true;
                for(int i=0;i<b.getRowDimension();i++){
                        for(int j=0;j<b.getColumnDimension();j++){
                                if(Math.abs(threshold)<=Math.abs(b.get(i, j))){//取绝对值比较
                                        flag = false;break;
                                }
                        }
                }
                return flag;
        }
        
        /**
         * 对pagerank进行排序输出,并保存在文件中  其中pagerank为1*n的矩阵
         * @throws IOException 
         */
        public static void rankSort(Matrix pagerank,ArrayList<String> s,int iter) throws IOException{
        	HashMap<String,Double> rMap = new HashMap<String,Double>(); 
        	
        	for(int i =0;i<s.size();i++){
        		rMap.put(s.get(i), pagerank.get(i, 0));//如果pagerank为1*n的矩阵则pagerank.get(i, 0)改为pagerank.get(0,i)
        	}
        	
        	List<Map.Entry<String, Double>> infoIds = new ArrayList<Map.Entry<String, Double>>(  
        	        rMap.entrySet()); 
        	
        	// 排序  
        	Collections.sort(infoIds, new Comparator<Map.Entry<String, Double>>() {  
        	    public int compare(Map.Entry<String, Double> o1,  
        	            Map.Entry<String, Double> o2) {  
        	    	 return (o1.getValue() < o2.getValue()) ? 1 : o1.getValue()  == o2.getValue() ? 0 : -1;  
        	    }  
        	}); 
        	
        	System.out.println("--------------排序后--------------");  

        	
        	File file = new File("result-CR.txt");
    		if(!file.exists()){
    			//System.out.println("result-CR.txt:文件不存在，创建此文件");
    			file.createNewFile();
    		}		
    		PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file)));
    		pw.println("迭代次数"+":  "+iter);//保存迭代次数
    		for (int i = 0; i < infoIds.size(); i++) {  
        	    Entry<String,Double> ent=infoIds.get(i);  
        	    System.out.println(ent.getKey()+":  "+ent.getValue());  
        	    pw.println(ent.getKey()+":  "+ent.getValue());
        	      
        	} 
    		pw.close();
        	
        }
}