package rhq.pr.data;

/**
 * 权重的数据描述
 * 
 * @author rhq
 *
 */

public class Weight {
	
	public String d1; 
	public String d2;
	public double weight;
	
	@Override
	public String toString() {
		return "d1:"+d1+"---d2:"+d2+"---weight:"+weight;
	}
	
	

}
