package pagerank.cal;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import rhq.pr.data.Weight;

public class CalculationWeight {
	
	//获取新的weight数据
	public static void main (String[] args) throws IOException{
		
		Map<String,Integer> numMap = new HashMap<String,Integer>();
		GetMa getMa  = new GetMa();
		String path = "08-12 weight f3.txt";//要重新计算的权重文件名
		//提取权重数据
		ArrayList<Weight> weightLlist = getMa.getWeight(path);
		//计算权重数据中第一个数据的重复个数
		String pre = weightLlist.get(0).d1;
		int num = 1;
		for(int i=1;i<weightLlist.size();i++){
			String temp = weightLlist.get(i).d1;
			if(temp.equals(pre))num++;
			else{
				numMap.put(pre, num);
				pre = temp;
				num=1;
			}	
		}
		numMap.put(pre, num);
		
		//将num乘到weight的数据中
		for(int i=0;i<weightLlist.size();i++){
			String temp = weightLlist.get(i).d1;
			int n = numMap.get(temp);
			Weight w = weightLlist.get(i);	
			w.weight = w.weight*n;
		}
		//将新数据保存
		saveWeightLlist2File(weightLlist , "08-12 weight f3–indegree.txt");	//08-12 weight f1–indegree.txt新的的权重文件名
	}
	
	/**
	 * 将weightLlist保存在新的文件中
	 * @param weightLlist
	 * @param path
	 * @throws IOException
	 */
	public static void saveWeightLlist2File(ArrayList<Weight> weightLlist , String path) throws IOException{
		File file = new File(path);
		if(!file.exists()){
			System.out.println(path+"不存在，创建此文件");
			file.createNewFile();
		}		
		PrintWriter pw = new PrintWriter(new OutputStreamWriter(new FileOutputStream(file)));
		for(int i=0;i<weightLlist.size();i++){
			Weight w = weightLlist.get(i);	
			pw.println(w.d1+"  &&&  "+w.d2+" :  "+w.weight);
		}
		pw.close();
		
	}


}
