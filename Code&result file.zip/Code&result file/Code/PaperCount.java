import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;

/**
 * Created by XIMING on 16/2/15.
 */
public class PaperCount {

    public static void main(String[] argv){
        Scanner scanner = null;
        BufferedWriter []bufferedWriter = new BufferedWriter[5];
        HashSet<String> set = new HashSet<String>();
        try {
            scanner = new Scanner(new FileInputStream("08-12 entities.txt"));
            for (int i = 0; i < 5; ++i){
                bufferedWriter[i] =
                        new BufferedWriter(new FileWriter(((new StringBuffer(String.valueOf(i+2008))).append(".txt")).toString()));
            }
            String cline = null;
            String tline = null;

            while (scanner.hasNextLine()){
                String line = scanner.nextLine();
                if (line.startsWith("#c")){
                    cline = line;
                } else if (line.startsWith("#t")){
                    StringBuffer tmp = new StringBuffer(line);
                    tmp.delete(0, 2);
                    int year = Integer.parseInt(tmp.toString());
                    if (year >= 2008 && year <= 2012){
                        tline = line;

                        if (set.contains(cline))
                            continue;
                        set.add(cline);
                        bufferedWriter[year-2008].write(cline);
                        bufferedWriter[year-2008].newLine();
         

                    }
                }
            }

            for (int i = 0; i < 5; ++i)
                bufferedWriter[i].close();
                scanner.close();

        }catch (IOException e){
            e.printStackTrace();
            return;
        }

    }
}
